

function argument(amount) {
    let discont = 0;
    if (amount < 500) {
        console.log(amount);

    } else if (amount >= 2000) {
        discont = amount * 25 / 100;
        console.log(amount - discont);
    } else if (amount < 2000 && amount >= 1500) {
        discont = amount * 20 / 100;
        console.log(amount - discont);

    } else if (amount >= 1000 && amount < 1500) {
        discont = amount * 15 / 100;
        console.log(amount - discont);
    } else if (amount >= 500 && amount < 1000) {
        discont = amount * 10 / 100;
        console.log(amount - discont);
    } else {
        console.log(amount);

    }

}


function calculateFinalprice(callback) {
    callback(300);
    callback(750);
    callback(1200);
    callback(1800);
    callback(2500);
}

calculateFinalprice(argument);

