
function isEven(amount) {
    let sum1 = 0;
    for (let i = 1; i <= 100; i++) {
        if (i % 2 == 0) {
            sum1 = sum1 + i;
        }
    }
    console.log("the sum of even number", sum1);
}

function isodd(amount) {
    let sum2 = 0;
    for (let i = 1; i <= 50; i++) {
        if (i % 2 !== 0) {
            sum2 = sum2 + i;
        }
    }
    console.log("the sum of odd number", sum2);
}


function isperfect(amount) {
    let sum3 = 0;
    for (let i = 1; i < 200; i++) {
        if (i * i < 200) {
            sum3 = sum3 + i * i;
        }
    }

    console.log("the sum of perfect number", sum3);
}

function higherorder(callback) {
    callback();
}

higherorder(isEven);
higherorder(isodd);
higherorder(isperfect);
