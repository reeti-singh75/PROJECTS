function outer(fn) {
    console.log("Start outer");
    fn();
    console.log("End outer");
}

function middle(callback) {
    console.log("Inside middle");
    callback();
}

function inner() {
    console.log("Innermost function");
}

console.log("Begin Program");

outer(function() {
    middle(inner);
});

console.log("Program Done");
