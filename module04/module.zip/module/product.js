



function isElectronic(products) {
    let store = [];
    for (let i = 0; i < products.length; i++) {
        if (products[i].category === "Electronics") {
            store.push(products[i].name)
        }
    }
    //   console.log(store);
    return store;
}


function isExpensive(products) {
    let store = [];
    for (let i = 0; i < products.length; i++) {
        if (products[i].price > 30) {
            store.push(products[i].name)
        }
    }
    //   console.log(store); 
    return store;
}


function isPreumElecronic(products) {
    let store = [];
    for (let i = 0; i < products.length; i++) {
        if (products[i].price > 100) {
            store.push(products[i].name)
        }
    }
    //   console.log(store);
    return store;
}





function filterproduct(arr, callback) {
    return callback(arr);
}


const products = [{ name: "Laptop", price: 800, category: "Electronics" },
{ name: "Book", price: 20, category: "Education " },
{ name: "Headphones", price: 50, category: "Electronics" },
{ name: "Pen", price: 2, category: "Stationery" }]


console.log(filterproduct(products, isElectronic));
console.log(filterproduct(products, isExpensive));
console.log(filterproduct(products, isPreumElecronic));



// filterproduct(products,isElectronic)
// filterproduct(products,isExpensive);
// filterproduct(products,isPreumElecronic);
