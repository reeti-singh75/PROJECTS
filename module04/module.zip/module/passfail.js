function student(stu){
let result = [];
for (let i = 0; i < stu.length; i++) {
    let avrage = 300 * 60 / 100;
    let check = stu[i].mark[0] + stu[i].mark[1] + stu[i].mark[2];
    if (check > avrage) {
        check = "pass"
    } else {
        check = "fail"
    }
result.push(`${stu[i].name}:${check}`)
}
console.log(result);}



function result(arr,callback) {
    callback(arr);
}



const stu = [{ name: "Alice", mark: [70, 85, 90] }, { name: "Bob", mark: [40, 55, 50] }, { name: "Charlie", mark: [60, 65, 58] }]
result(stu,student);

